import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "RexStudios",
  description: "Minecraft Map Portfolio",
};